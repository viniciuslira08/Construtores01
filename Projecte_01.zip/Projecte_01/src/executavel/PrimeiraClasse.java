package executavel;

import classes.Aluno;

public class PrimeiraClasse {
    public static void main(String[] args) {

        /*new Aluno é uma instancia criação de objetos*/
        /*aluno1 é uma referencia para o objeto aluno */
        Aluno aluno = new Aluno(); /*Aqui será o João*/

        aluno.setNome("João");
        aluno.setIdade(39);
        aluno.setNota1(80);
        aluno.setNota2(90);

        System.out.println("O nome do Aluno : " + aluno.getNome());
        System.out.println("A idade do Aluno : " + aluno.getIdade());
        System.out.println("A Primeira Nota : " + aluno.getNota1());
        System.out.println("A Segunda Nota : " + aluno.getNota2());
        System.out.println("A media do Aluno : " +aluno.calcularMedia());
        System.out.println("O aluno foi : " +aluno.alunoAprovacacao());
        System.out.println("Resultado = " +aluno.alunoAprovado());

    }
}
